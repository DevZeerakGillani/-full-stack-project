export type PagingQueryParams = {
    top?: string
    skip?: string
}